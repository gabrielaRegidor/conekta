<?php 

namespace Conekta;

use \Conekta\ConektaResource;

class Method extends ConektaResource
{
}
